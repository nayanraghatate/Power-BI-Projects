# Sales-Dashboard
Sales report and Dashboard using Power BI.

Here's a Data-Analysis project of Sales Report using Power-BI. Check out my project and give your valuable review.


# These are some Screenshot of Sales Report.
<img src="https://github.com/abhi-511/Sales-Dashboard/blob/main/ScreenShots/S1.png" alt="alt text" height=300 width="500"/>         <img src="https://github.com/abhi-511/Sales-Dashboard/blob/main/ScreenShots/S2.png" alt="drawing"  height=300 width="500"/>

# These are the screenshot of mobile-layout.
<img src="https://github.com/abhi-511/Sales-Dashboard/blob/main/ScreenShots/S4.png" alt="drawing"  height=300 width="500"/>         <img src="https://github.com/abhi-511/Sales-Dashboard/blob/main/ScreenShots/S3.png" alt="drawing"  height=300 width="500"/>         


Please do ⭐ the repository, if you like this.😊


### Connect with me:


[<img align="left" alt="codeSTACKr | Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg" />][twitter]
[<img align="left" alt="codeSTACKr | LinkedIn" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />][linkedin]
[<img align="left" alt="codeSTACKr | Instagram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/instagram.svg" />][instagram]

<br />

<br />
 📧 Email : me.gupta511@gmail.com




[twitter]: https://twitter.com/Abhijit89577918
[instagram]: https://www.instagram.com/_abhijit_gupta_/
[linkedin]: https://www.linkedin.com/in/abhijit-gupta-764a96209/
